# _event-logging-xml-schema_ Content Pack

## Contents

The following represents the folder structure and content that will be imported in to Stroom with this content pack.

* _XML Schemas_ 
    * _event-logging_ 
        * **event-logging v3.0.0** `XMLSchema`

            Version 3.0.0 of the event-logging XMLSchema.

        * **event-logging v3.1.1** `XMLSchema`

            Version 3.1.1 of the event-logging XMLSchema.


